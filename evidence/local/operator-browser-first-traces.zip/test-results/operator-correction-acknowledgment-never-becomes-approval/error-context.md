# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: operator.spec.ts >> correction acknowledgment never becomes approval
- Location: tests\e2e\operator.spec.ts:97:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.selectOption: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByLabel('Station', { exact: true })

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to main content" [ref=e3] [cursor=pointer]:
    - /url: "#main"
  - banner [ref=e4]:
    - link "ProofPack home" [ref=e5] [cursor=pointer]:
      - /url: /
      - generic [aria-hidden] [ref=e6]: P
      - text: ProofPack
    - generic [ref=e7]: Invited workspace
  - main [ref=e8]:
    - generic [ref=e9]: Visible kit checks · human decisions
    - heading "A clear check. An honest next step." [level=1] [ref=e10]: A clear check.An honest next step.
    - paragraph [ref=e11]: Check configured visible parts against an approved recipe. When the view is uncertain, resolve it or ask for a manual review.
    - region [ref=e12]:
      - generic [ref=e13]:
        - text: Your workspace
        - heading "Before you begin" [level=2] [ref=e14]
      - status [ref=e15]:
        - strong [ref=e16]: Inspections are not available yet
        - paragraph [ref=e17]: Continue with your ordinary manual check. Ask the workspace owner before starting a supervised session.
      - button "Check again" [ref=e18] [cursor=pointer]: Check again ↗
    - region [ref=e19]:
      - heading "Operator workspace" [level=2] [ref=e20]
      - status "Workspace message" [ref=e21]: Choose the approved station and recipe for this kit.
      - generic [ref=e22]:
        - generic [ref=e23]: "Signed in: Fixture operator · operator"
        - button "Sign out" [ref=e24] [cursor=pointer]
      - button "Load stations and recipes" [ref=e25] [cursor=pointer]
      - generic [ref=e26]:
        - generic [ref=e27]:
          - text: Station
          - combobox "Station" [ref=e28]:
            - option "Choose station" [selected]
            - option "Synthetic station"
        - generic [ref=e29]:
          - text: Approved recipe
          - combobox "Approved recipe" [ref=e30]:
            - option "Choose recipe" [selected]
            - option "Synthetic recipe"
        - generic [ref=e31]:
          - text: Opaque kit reference
          - textbox "Opaque kit reference" [ref=e32]:
            - /placeholder: No names or shipping details
      - generic [ref=e33]:
        - button "Acquire station" [disabled] [ref=e34]
        - button "Start kit inspection" [disabled] [ref=e35]
      - generic [ref=e36]:
        - generic [ref=e37]:
          - text: Human disposition (separate from machine result)
          - combobox "Human disposition (separate from machine result)" [ref=e38]:
            - option "No disposition selected" [selected]
            - option "Rework"
            - option "Reject"
            - option "Cancelled"
            - option "Accepted after human check"
        - generic [ref=e39]:
          - text: Handoff / close reason
          - textbox "Handoff / close reason" [ref=e40]:
            - /placeholder: No personal or shipping information
      - generic [ref=e41]:
        - button "Close kit inspection" [disabled] [ref=e42]
        - button "Release station" [disabled] [ref=e43]
      - paragraph [ref=e44]: For unresolved checks, account problems or unavailable support, stop and ask the owner or supervisor. Use the ordinary manual check. Starting a replacement inspection does not resolve uncertainty.
    - region [ref=e45]:
      - heading "Know what a result means" [level=2] [ref=e46]
      - generic [ref=e47]:
        - article [ref=e48]:
          - generic [ref=e49]: "01"
          - heading "Visible, configured parts" [level=3] [ref=e50]
          - paragraph [ref=e51]: A qualified recipe defines what can be checked. Hidden contents, material grade and thread specifications need another method.
        - article [ref=e52]:
          - generic [ref=e53]: "02"
          - heading "A current observation" [level=3] [ref=e54]
          - paragraph [ref=e55]: Moving parts or losing the live view makes an old result historical. A screenshot or export cannot confirm the current kit.
        - article [ref=e56]:
          - generic [ref=e57]: "03"
          - heading "You remain in control" [level=3] [ref=e58]
          - paragraph [ref=e59]: Stop when unsure and ask for help. Manually verify the entire kit before packing during the supervised beta. ProofPack does not authorize shipment.
    - group [ref=e60]:
      - generic "Camera, privacy and participation" [ref=e61] [cursor=pointer]
  - contentinfo [ref=e62]:
    - text: ProofPack
    - generic [ref=e63]: Configured observations. Accountable decisions.
```

# Test source

```ts
  1   | /** Browser/API/stream fixtures only: no real login, camera, physical truth or AWS. */
  2   | import { test, expect } from '@playwright/test';
  3   | import type { Page } from '@playwright/test';
  4   | import path from 'node:path';
  5   | 
  6   | const stationId='10000000-0000-4000-8000-000000000001', recipeId='20000000-0000-4000-8000-000000000001';
  7   | const inspectionId='30000000-0000-4000-8000-000000000001', actionId='40000000-0000-4000-8000-000000000001';
  8   | 
  9   | async function fixture(page: Page, options: { role?: string; action?: boolean; delay?: number; logoutFail?: boolean; geometryFail?: boolean } = {}) {
  10  |   await page.addInitScript(() => {
  11  |     const state={requests:0,stops:0,color:'#35483c',deny:false};
  12  |     Object.assign(window,{fixtureCamera:state});
  13  |     Object.defineProperty(navigator.mediaDevices,'enumerateDevices',{value:async()=>[]});
  14  |     Object.defineProperty(navigator.mediaDevices,'getUserMedia',{value:async()=>{
  15  |       state.requests++;
  16  |       if(state.deny)throw new DOMException('fixture permission denied','NotAllowedError');
  17  |       const canvas=document.createElement('canvas');canvas.width=640;canvas.height=480;
  18  |       const draw=()=>{const c=canvas.getContext('2d')!;c.fillStyle=state.color;c.fillRect(0,0,640,480);};draw();
  19  |       const timer=window.setInterval(draw,100);const stream=canvas.captureStream(10);
  20  |       for(const track of stream.getTracks()){const stop=track.stop.bind(track);track.stop=()=>{state.stops++;window.clearInterval(timer);stop();};}
  21  |       return stream;
  22  |     }});
  23  |   });
  24  |   const station={id:stationId,name:'Synthetic station',state_version:1,epoch:0,owner_session_id:null as string|null,active_inspection_id:null as string|null,
  25  |     owned_by_current_session:false,calibration_profile_id:'synthetic-profile'};
  26  |   let state='CREATED', version=1, sequence=0, observations=0, uploads=0, acknowledgments=0;
  27  |   const result=()=>({id:inspectionId,station_id:stationId,state_version:version,effective_state:state,remaining_lease_ms:state==='PASSED_CURRENT'?900:0,
  28  |     last_observed_at:observations?Date.now():null,action:state==='ACTION_REQUIRED'?{id:actionId,kind:'SEPARATE_REGION',message:'Separate the parts in the highlighted region, then recheck.'}:null});
  29  |   await page.route('**/api/v1/**',async route=>{
  30  |     const request=route.request(), url=new URL(request.url()), pathname=url.pathname.slice('/api/v1'.length), method=request.method();
  31  |     const json=(value:unknown,status=200)=>route.fulfill({status,json:value});
  32  |     if(pathname==='/me')return json({id:'operator',display_name:'Fixture operator',roles:[options.role??'operator'],session_id:'session-fixture',csrf_token:'a'.repeat(43)});
  33  |     if(pathname==='/stations')return json({stations:[station],next_cursor:null});
  34  |     if(pathname==='/recipes')return json({recipes:[{id:recipeId,name:'Synthetic recipe'}],next_cursor:null});
  35  |     if(pathname===`/stations/${stationId}`)return json(station);
  36  |     if(pathname===`/stations/${stationId}/acquire`){expect(request.postDataJSON().expected_owner_session_id).toBeNull();station.epoch=1;station.state_version++;station.owner_session_id='session-fixture';station.owned_by_current_session=true;return json({current:station});}
  37  |     if(pathname==='/inspections'&&method==='POST'){expect(request.postDataJSON().kit_id).toBe('kit-1');station.active_inspection_id=inspectionId;station.state_version++;return json({inspection_id:inspectionId,state_version:1},201);}
  38  |     if(pathname===`/inspections/${inspectionId}`)return json(result());
  39  |     if(pathname.endsWith('/capture-context')){
  40  |       if(options.geometryFail)return json({code:'DEPENDENCY_UNAVAILABLE'},503);
  41  |       return json({context_version:1,capture_transform:'center_crop_resize_no_upscale',inspection_id:inspectionId,
  42  |         recipe_name:'Synthetic recipe',recipe_revision:1,data_origin:'synthetic',policy_mode:'deterministic_policy',camera_label:'Fixture camera',
  43  |         frame_width:320,frame_height:240,work_polygon:[[.1,.1],[.9,.1],[.9,.9],[.1,.9]],constraints:[{constraint_id:'washers',part_class_id:'washers',expected_count:1}],remaining_context_ms:60000});
  44  |     }
  45  |     if(pathname.endsWith('/prepare-capture'))return json({ready:true,inspection_state_version:version});
  46  |     if(pathname.endsWith('/capture-permits')){expect(Number(request.headers()['if-match'])).toBe(version);version++;sequence++;return json({permit_id:actionId,nonce:'a'.repeat(43),sequence,inspection_state_version:version,usable:true},201);}
  47  |     if(pathname.endsWith('/observations')){
  48  |       uploads++;expect(request.headers()['content-type']).toContain('multipart/form-data; boundary=');
  49  |       expect(Number(request.headers()['if-match'])).toBe(version);
  50  |       const bytes=request.postDataBuffer()!;expect(bytes.includes(Buffer.from('capture.jpg'))).toBeTruthy();expect(bytes.includes(Buffer.from([255,216,255]))).toBeTruthy();
  51  |       if(options.delay)await new Promise(resolve=>setTimeout(resolve,options.delay));
  52  |       observations++;version++;state=options.action&&acknowledgments===0?'ACTION_REQUIRED':observations>=3||options.delay?'PASSED_CURRENT':'OBSERVING';
  53  |       return json({observation_id:inspectionId,sequence,operation_status:'completed',replayed:false,measurement:{findings:[state==='ACTION_REQUIRED'?'UNOBSERVABLE':'SATISFIED']},status:result()});
  54  |     }
  55  |     if(pathname.endsWith(`/actions/${actionId}/complete`)){acknowledgments++;version++;state='OBSERVING';return json(result());}
  56  |     if(pathname.endsWith('/close')){expect(request.postDataJSON().reason).toBeTruthy();state='CLOSED';station.active_inspection_id=null;station.epoch++;station.state_version++;return json({current:station});}
  57  |     if(pathname.endsWith('/release')){station.owner_session_id=null;station.owned_by_current_session=false;station.active_inspection_id=null;station.epoch++;station.state_version++;return json({current:station});}
  58  |     if(pathname==='/auth/logout')return options.logoutFail?route.abort('failed'):route.fulfill({status:204});
  59  |     throw new Error(`Unexpected fixture API request: ${method} ${pathname}`);
  60  |   });
  61  |   return {get uploads(){return uploads;},get acknowledgments(){return acknowledgments;}};
  62  | }
  63  | 
  64  | async function openKit(page:Page) {
  65  |   await page.bringToFront();await page.goto('/');await page.getByRole('button',{name:'Open invited workspace'}).click();
  66  |   await page.getByRole('button',{name:'Load stations and recipes'}).click();
> 67  |   await page.getByLabel('Station',{exact:true}).selectOption(stationId);await page.getByLabel('Approved recipe',{exact:true}).selectOption(recipeId);
      |                                                 ^ Error: locator.selectOption: Test timeout of 30000ms exceeded.
  68  |   await page.getByLabel('Opaque kit reference').fill('kit-1');await page.getByRole('button',{name:'Acquire station',exact:true}).click();
  69  |   await expect(page.getByRole('status',{name:'Workspace message'})).toContainText('Station acquired');
  70  |   await page.getByRole('button',{name:'Start kit inspection',exact:true}).click();
  71  |   await expect(page.getByRole('heading',{name:'Synthetic recipe · revision 1'})).toBeVisible();
  72  | }
  73  | async function startChecks(page:Page){
  74  |   await page.getByRole('button',{name:'Start camera preview'}).click();
  75  |   await expect(page.getByRole('status',{name:'Workspace message'})).toContainText('Preview only');
  76  |   await page.getByLabel('I checked the full transmitted area',{exact:false}).check();
  77  |   await page.getByRole('button',{name:'Start fresh checks'}).click();
  78  | }
  79  | 
  80  | test('operator completes a fixture kit, then stops, closes, releases and signs out',async({page})=>{
  81  |   const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));const calls=await fixture(page);await openKit(page);
  82  |   expect(await page.evaluate(()=>Reflect.get(window,'fixtureCamera').requests)).toBe(0);expect(calls.uploads).toBe(0);
  83  |   await startChecks(page);
  84  |   await expect(page.getByRole('heading',{name:'Visible checks passed — current observation',exact:true})).toBeVisible();
  85  |   await page.getByRole('button',{name:'Stop camera and checks'}).click();
  86  |   await expect(page.getByRole('heading',{name:'Recheck required — no current approval'})).toBeVisible();
  87  |   expect(await page.evaluate(()=>Reflect.get(window,'fixtureCamera').stops)).toBeGreaterThan(0);
  88  |   await page.getByLabel('Human disposition (separate from machine result)').selectOption('human_accepted');
  89  |   await page.getByLabel('Handoff / close reason').fill('Manual check complete');
  90  |   await page.getByRole('button',{name:'Close kit inspection',exact:true}).click();
  91  |   await expect(page.getByRole('status',{name:'Workspace message'})).toContainText('Inspection closed');
  92  |   await page.getByRole('button',{name:'Release station',exact:true}).click();
  93  |   await page.getByRole('button',{name:'Sign out',exact:true}).click();
  94  |   await expect(page.getByRole('status',{name:'Workspace message'})).toContainText('Signed out of ProofPack');expect(errors).toEqual([]);
  95  | });
  96  | 
  97  | test('correction acknowledgment never becomes approval',async({page})=>{
  98  |   const calls=await fixture(page,{action:true});await openKit(page);await startChecks(page);
  99  |   await expect(page.getByRole('heading',{name:'Action required',exact:true})).toBeVisible();expect(calls.uploads).toBe(1);
  100 |   await page.getByRole('button',{name:'Acknowledge correction completed'}).click();
  101 |   expect(calls.acknowledgments).toBe(1);await expect(page.getByRole('heading',{name:'Visible checks passed — current observation',exact:true})).toHaveCount(0);
  102 |   await expect(page.getByRole('status',{name:'Workspace message'})).toContainText('not a pass');
  103 | });
  104 | 
  105 | test('owner-only account does not receive operator controls',async({page})=>{
  106 |   await fixture(page,{role:'owner'});await page.bringToFront();await page.goto('/');await page.getByRole('button',{name:'Open invited workspace'}).click();
  107 |   await expect(page.getByRole('status',{name:'Workspace message'})).toContainText('no operator grant');await expect(page.getByRole('button',{name:'Start kit inspection',exact:true})).toHaveCount(0);
  108 | });
  109 | 
  110 | test('permission denial and missing geometry block capture without replacing work',async({page})=>{
  111 |   const calls=await fixture(page);await openKit(page);await page.evaluate(()=>Reflect.get(window,'fixtureCamera').deny=true);
  112 |   await page.getByRole('button',{name:'Start camera preview'}).click();await expect(page.getByRole('status',{name:'Workspace message'})).toContainText('Camera permission denied');
  113 |   expect(calls.uploads).toBe(0);await expect(page.getByRole('button',{name:'Start fresh checks'})).toBeDisabled();
  114 |   await page.evaluate(()=>Reflect.get(window,'fixtureCamera').deny=false);await startChecks(page);await expect.poll(()=>calls.uploads).toBeGreaterThan(0);
  115 | });
  116 | 
  117 | test('late pass response cannot renew a lease and offline logout remains unconfirmed',async({page})=>{
  118 |   await fixture(page,{delay:1100,logoutFail:true});await openKit(page);await startChecks(page);
  119 |   await expect(page.getByText('Last observation findings',{exact:true})).toBeVisible();
  120 |   await expect(page.getByRole('heading',{name:'Visible checks passed — current observation',exact:true})).toHaveCount(0);
  121 |   await page.getByRole('button',{name:'Sign out',exact:true}).click();await expect(page.getByRole('status',{name:'Workspace message'})).toContainText('Server sign-out is unconfirmed');
  122 |   await expect(page.getByRole('button',{name:'Retry sign out',exact:true})).toBeVisible();expect(await page.evaluate(()=>Reflect.get(window,'fixtureCamera').stops)).toBeGreaterThan(0);
  123 | });
  124 | 
  125 | test('hidden page clears approval and stops the fixture stream',async({page})=>{
  126 |   await fixture(page);await openKit(page);await startChecks(page);await expect(page.getByRole('heading',{name:'Visible checks passed — current observation',exact:true})).toBeVisible();
  127 |   await page.evaluate(()=>{Object.defineProperty(document,'visibilityState',{configurable:true,get:()=> 'hidden'});document.dispatchEvent(new Event('visibilitychange'));});
  128 |   await expect(page.getByRole('heading',{name:'Recheck required — no current approval'})).toBeVisible();
  129 |   expect(await page.evaluate(()=>Reflect.get(window,'fixtureCamera').stops)).toBeGreaterThan(0);
  130 | });
  131 | 
  132 | test('missing geometry preserves status and supports close; keyboard, zoom and contrast layout',async({page})=>{
  133 |   await fixture(page,{geometryFail:true});await page.setViewportSize({width:1366,height:768});await page.emulateMedia({forcedColors:'active',reducedMotion:'reduce'});
  134 |   await page.bringToFront();await page.goto('/');await page.getByRole('button',{name:'Open invited workspace'}).click();await page.getByRole('button',{name:'Load stations and recipes'}).click();
  135 |   await page.getByLabel('Station',{exact:true}).selectOption(stationId);await page.getByLabel('Approved recipe',{exact:true}).selectOption(recipeId);await page.getByLabel('Opaque kit reference').fill('kit-1');
  136 |   await page.getByRole('button',{name:'Acquire station',exact:true}).click();await expect(page.getByRole('status',{name:'Workspace message'})).toContainText('Station acquired');
  137 |   await page.getByRole('button',{name:'Start kit inspection',exact:true}).click();await expect(page.getByRole('status',{name:'Workspace message'})).toContainText('unavailable');
  138 |   await expect(page.getByRole('button',{name:'Refresh inspection status'})).toBeVisible();await expect(page.getByRole('button',{name:'Start camera preview'})).toHaveCount(0);
  139 |   await page.evaluate(()=>{document.documentElement.style.zoom='2';});await page.keyboard.press('Tab');
  140 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth)).toBeTruthy();
  141 |   await page.screenshot({path:path.resolve(__dirname,'../../evidence/local/operator-missing-geometry-zoom.png'),fullPage:true});
  142 | });
  143 | 
```